export class Task {

    id :  number ;
    projectsName: string ;
    taskName: string ;
email: string;

}
